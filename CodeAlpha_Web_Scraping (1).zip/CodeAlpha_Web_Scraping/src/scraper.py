"""
CodeAlpha Internship - Task 1: Web Scraping
Scrapes book data from Books to Scrape, a website created for scraping practice.
"""

import time
import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin

BASE_URL = "https://books.toscrape.com/"
START_URL = urljoin(BASE_URL, "catalogue/page-1.html")
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; CodeAlphaIntern/1.0)"}

RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}

def scrape_pages(max_pages=3):
    records = []
    session = requests.Session()
    session.headers.update(HEADERS)

    for page in range(1, max_pages + 1):
        url = urljoin(BASE_URL, f"catalogue/page-{page}.html")
        response = session.get(url, timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        for item in soup.select("article.product_pod"):
            title_tag = item.select_one("h3 a")
            price_tag = item.select_one(".price_color")
            rating_tag = item.select_one("p.star-rating")
            availability_tag = item.select_one(".availability")

            if not title_tag:
                continue

            title = title_tag.get("title", title_tag.get_text(strip=True))
            product_url = urljoin(url, title_tag.get("href", ""))
            rating_class = next(
                (c for c in rating_tag.get("class", []) if c in RATING_MAP),
                None
            ) if rating_tag else None

            records.append({
                "title": title,
                "price_gbp": price_tag.get_text(strip=True).replace("£", "") if price_tag else None,
                "rating_text": rating_class,
                "rating": RATING_MAP.get(rating_class),
                "availability": availability_tag.get_text(" ", strip=True) if availability_tag else None,
                "product_url": product_url
            })

        time.sleep(0.5)

    return pd.DataFrame(records)

if __name__ == "__main__":
    df = scrape_pages(max_pages=3)
    df.to_csv("data/raw_books.csv", index=False)
    print(f"Saved {len(df)} scraped records to data/raw_books.csv")
