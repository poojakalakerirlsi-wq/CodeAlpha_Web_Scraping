# CodeAlpha Internship - Task 1: Web Scraping

## Project Title
**E-Commerce Book Data Web Scraping and Analysis**

## Objective
The objective of this project is to demonstrate how Python can be used to collect structured information from a public web page, create a custom dataset, preprocess the collected data, and perform basic analysis and visualization.

## Website Used
**Books to Scrape** — https://books.toscrape.com/

Books to Scrape is a website specifically designed for web-scraping practice. It provides book listings with fields such as title, price, rating and availability.

## Technologies Used
- Python
- Requests
- BeautifulSoup
- Pandas
- Matplotlib
- Jupyter Notebook

## Dataset Fields

| Column | Description |
|---|---|
| title | Book title |
| category | Book category |
| price_gbp | Price in GBP |
| rating_text | Original rating text |
| rating | Numeric rating from 1 to 5 |
| availability | Stock availability |
| product_url | Product page URL |
| price_band | Derived price category |

## Project Workflow

```text
Public Web Page
      ↓
Requests
      ↓
BeautifulSoup
      ↓
Data Extraction
      ↓
Raw CSV Dataset
      ↓
Data Cleaning & Preprocessing
      ↓
Cleaned Dataset
      ↓
Analysis
      ↓
Visualization
```

## Key Features
1. Scrapes multiple pages automatically.
2. Extracts book title, price, rating, availability and URL.
3. Converts ratings from text to numerical values.
4. Converts prices to numeric format.
5. Removes duplicate records.
6. Handles missing values.
7. Creates a custom `price_band` feature.
8. Generates analytical charts.
9. Saves raw and cleaned datasets separately.

## How to Run

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the scraper

```bash
python src/scraper.py
```

This creates:

```text
data/raw_books.csv
```

### 3. Preprocess the data

```bash
python src/preprocessing.py
```

This creates:

```text
data/cleaned_books.csv
```

### 4. Run analysis

```bash
python src/analysis.py
```

Charts are saved inside:

```text
outputs/
```

## Sample Analysis Questions
- What is the average book price?
- Which category has the highest average price?
- Which books have the highest ratings?
- How are ratings distributed?
- What is the distribution of book prices?
- Which price band contains the most books?

## Ethical and Responsible Scraping
This project uses Books to Scrape, a website designed for scraping practice. The scraper uses a descriptive User-Agent, reasonable request delays, and a limited number of pages. Production scraping should always respect a website's terms of use, robots.txt, rate limits, copyright and applicable laws.

## Internship Task Mapping

**Task 1: Web Scraping**
- Python + BeautifulSoup: Completed
- Public web data collection: Completed
- Custom dataset creation: Completed
- Data preprocessing: Completed
- Data analysis: Completed
- Data visualization: Completed

## Author
**Pooja Sanjeev Kalakeri**

B.Sc. Data Science
