raw_books.csv is a sample captured dataset for demonstration. Run src/scraper.py to regenerate it from the practice website.
