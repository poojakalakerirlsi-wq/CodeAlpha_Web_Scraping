"""
Clean and preprocess the scraped dataset.
"""

import pandas as pd

RATING_MAP = {"One":1, "Two":2, "Three":3, "Four":4, "Five":5}

def clean_data(input_file="data/raw_books.csv", output_file="data/cleaned_books.csv"):
    df = pd.read_csv(input_file)

    df["title"] = df["title"].astype("string").str.replace(r"\s+", " ", regex=True).str.strip()
    df["price_gbp"] = pd.to_numeric(df["price_gbp"], errors="coerce")

    if "rating" not in df.columns:
        df["rating"] = df["rating_text"].map(RATING_MAP)

    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    df["availability"] = df["availability"].astype("string").str.strip()

    df = df.drop_duplicates(subset=["title"])
    df = df.dropna(subset=["title", "price_gbp", "rating"])

    df["price_band"] = pd.cut(
        df["price_gbp"],
        bins=[0, 20, 40, 60],
        labels=["Under £20", "£20–£40", "Above £40"],
        include_lowest=True
    )

    df.to_csv(output_file, index=False)
    print(f"Cleaned dataset saved to {output_file}")
    return df

if __name__ == "__main__":
    clean_data()
