"""
Basic analysis and visualizations for the cleaned scraping dataset.
"""

import pandas as pd
import matplotlib.pyplot as plt

INPUT = "data/cleaned_books.csv"

def analyze():
    df = pd.read_csv(INPUT)

    print("\n--- Summary ---")
    print(df[["price_gbp", "rating"]].describe())

    print("\n--- Average price by category ---")
    print(df.groupby("category", dropna=False)["price_gbp"].mean().sort_values(ascending=False))

    print("\n--- Average rating by category ---")
    print(df.groupby("category", dropna=False)["rating"].mean().sort_values(ascending=False))

    print("\n--- Top 5 most expensive books ---")
    print(df.nlargest(5, "price_gbp")[["title", "price_gbp", "rating"]])

    print("\n--- Top 5 highest-rated books ---")
    print(df.nlargest(5, "rating")[["title", "price_gbp", "rating"]])

    # Price by category
    category_price = df.groupby("category")["price_gbp"].mean().sort_values(ascending=False)
    plt.figure(figsize=(10,5))
    category_price.plot(kind="bar")
    plt.title("Average Book Price by Category")
    plt.xlabel("Category")
    plt.ylabel("Average Price (£)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig("outputs/average_price_by_category.png", dpi=150)
    plt.close()

    # Rating distribution
    plt.figure(figsize=(7,5))
    df["rating"].value_counts().sort_index().plot(kind="bar")
    plt.title("Rating Distribution")
    plt.xlabel("Rating")
    plt.ylabel("Number of Books")
    plt.tight_layout()
    plt.savefig("outputs/rating_distribution.png", dpi=150)
    plt.close()

    # Price distribution
    plt.figure(figsize=(8,5))
    df["price_gbp"].plot(kind="hist", bins=8)
    plt.title("Book Price Distribution")
    plt.xlabel("Price (£)")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig("outputs/price_distribution.png", dpi=150)
    plt.close()

if __name__ == "__main__":
    analyze()
